{-# LANGUAGE DeriveGeneric #-}
{-# LANGUAGE DeriveAnyClass #-}
{-# LANGUAGE OverloadedStrings #-}

module Lib where

import Web.Scotty (scotty, get, json, text, status, ActionM)
import Network.HTTP.Simple
import qualified Data.ByteString.Lazy.Char8 as L8
import Data.Aeson (FromJSON, ToJSON, decode)
import GHC.Generics (Generic)
import Control.Monad.IO.Class (liftIO)
import Network.HTTP.Types.Status (status500)


-- Define a data type for weather data
data WeatherData = WeatherData {
    main :: MainWeather
} deriving (Show, Generic, ToJSON)

data MainWeather = MainWeather {
    temp :: Float,
    humidity :: Int
} deriving (Show, Generic, ToJSON)

-- Aeson instances for JSON parsing
instance FromJSON WeatherData
instance FromJSON MainWeather

-- Fetch weather data from OpenWeatherMap
fetchWeatherData :: String -> Float -> Float -> IO (Response L8.ByteString)
fetchWeatherData apiKey lat lon = do
    let apiEndpoint = "http://api.openweathermap.org/data/2.5/weather?lat=" ++ show lat ++ "&lon=" ++ show lon ++ "&appid=" ++ apiKey
    request <- parseRequest apiEndpoint
    httpLBS request

-- Store weather data in a file
storeWeatherData :: L8.ByteString -> FilePath -> IO ()
storeWeatherData weatherData filename = L8.writeFile filename weatherData

-- Convert Kelvin to Fahrenheit
kelvinToFahrenheit :: Float -> Float
kelvinToFahrenheit k = (k - 273.15) * 9/5 + 32

-- Define a route to handle weather data
weatherRoute :: ActionM ()
weatherRoute = do
    let apiKey = "43227aead2fa7bd3f2af255f98a5a53a"
    let lat = 41.8077
    let lon = 72.2540
    response <- liftIO $ fetchWeatherData apiKey lat lon
    let weatherData = getResponseBody response
    case decode weatherData :: Maybe WeatherData of
        Just wd -> json wd
        Nothing -> status status500 >> text "Failed to parse weather data"
