module Main where

import Web.Scotty (scotty, get)
import Lib (weatherRoute)

import qualified Web.Scotty as S

main :: IO ()
main = S.scotty 3000 $ do
  S.get "/weather" weatherRoute


